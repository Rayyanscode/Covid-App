import React from 'react';
let Footr = () => {
    return (
        <div style={{
            backgroundColor:"#4b4b4b",
            padding:"25px",
            color:"whitesmoke"
        }}>
            <footer>
                <div>
                    <h3><b>Developer : Muhammad Rayyan Khan</b></h3>
                    <h3><b>github : Rayyan's Code.</b></h3>
                </div>
            </footer>

        </div>
    )
}
export default Footr;